# -*- coding: utf-8 -*-
"""
声趣语音镜像 - 本地回放服务器 (Python 标准库, 零依赖)
======================================================
两层回放:

A. 静态资源 (逐字节镜像)
   /                 mirror/index.html
   /assets/*         mirror/assets/*
   /api/media/**     mirror/api/media/**

B. API 层 (线上为同源 Express 后端, 未登录仅 /api/rooms /api/room-types
   /api/auth/session /api/auth/captcha 公开; 其余 401/404)
   为让房间页 (Jg 模板) 可完整呈现, 本服务器在严格复刻公开快照的基础上,
   按 bundle 反推的数据契约提供本地会话:
     - POST /api/auth/login      任意凭证登录 (镜像会话 Cookie)
     - GET  /api/auth/session    {authenticated,user,csrfToken}
     - POST /api/rooms/:id/join  返回无 LiveKit 凭证的降级 ticket
                                (与线上 voiceAvailable:false 房间同路径)
     - GET  /api/rooms/:id       {room,members,speakers}
     - GET  /api/rooms/:id/chat  {enabled,messages}
     - 心跳/上麦/公屏等交互在内存中维护
   LiveKit WebRTC 语音为真实 SFU 服务, 镜像不含服务器, 故房间页呈现
   "实时语音未连接 / 语音连接失败: 服务器未返回语音凭证" 的真实降级态。

用法: python server.py [port]   默认 8088
"""
import copy
import json
import mimetypes
import os
import sys
import threading
import time
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, unquote

ROOT = os.path.dirname(os.path.abspath(__file__))
FIXTURES = os.path.join(ROOT, "fixtures")

mimetypes.add_type("application/javascript", ".js")
mimetypes.add_type("text/css", ".css")
mimetypes.add_type("image/webp", ".webp")

NGINX_404 = ("<html>\r\n<head><title>404 Not Found</title></head>\r\n<body>\r\n"
             "<center><h1>404 Not Found</h1></center>\r\n"
             "<hr><center>nginx</center>\r\n</body>\r\n</html>\r\n").encode()

SESSION_COOKIE = "mirror_session"
CSRF_TOKEN = "mirror-csrf-9f3a21"

GUEST = {
    "id": 10001,
    "userId": 10001,
    "username": "镜像访客",
    "name": "镜像访客",
    "account": "100000888",
    "accountId": "100000888",
    "userNo": "100000888",
    "avatarUrl": None,
    "avatar": None,
    "roomSeconds": 0,
    "level": 1,
}

# --------------------------------------------------------------- 镜像内存状态
LOCK = threading.Lock()


def load_json(name, default):
    p = os.path.join(FIXTURES, name)
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return default


STATE = {
    "rooms_doc": load_json("rooms.json", {"rooms": []}),       # 采集快照
    "sessions": set(),                                         # 已登录会话 token
    "rooms": {},                                               # rid -> room-0.json 结构
    "chats": {},                                               # rid -> [{user,content,createdAt}]
    "join_since": {},                                          # (token,rid) -> ts
    "next_rid": 100,
}

# 从快照预载房间
for _r in STATE["rooms_doc"].get("rooms", []):
    _rid = str(_r["id"])
    snap = load_json(f"room-{_rid}.json", None)
    if snap:
        STATE["rooms"][_rid] = copy.deepcopy(snap)
    else:
        STATE["rooms"][_rid] = {"room": copy.deepcopy(_r), "members": [], "speakers": []}
    STATE["chats"][_rid] = []


# --------------------------------------------------------------- 工具
def api_body(code, message, status):
    return status, json.dumps({"error": {"code": code, "message": message}},
                              ensure_ascii=False).encode("utf-8")


def jdump(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def public_user():
    u = dict(GUEST)
    return u


class Handler(BaseHTTPRequestHandler):
    server_version = "mirror/1.0"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    # ---------- 响应 ----------
    def send_bytes(self, status, body, ctype, extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Access-Control-Allow-Credentials", "true")
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)

    def send_json(self, status, obj, extra_headers=None):
        self.send_bytes(status, jdump(obj), "application/json; charset=utf-8", extra_headers)

    def send_api_error(self, code, message, status):
        st, body = api_body(code, message, status)
        self.send_bytes(st, body, "application/json; charset=utf-8")

    def send_file(self, fs_path, immutable=False):
        try:
            with open(fs_path, "rb") as f:
                body = f.read()
        except OSError:
            return False
        ctype = mimetypes.guess_type(fs_path)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype == "application/javascript":
            ctype += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control",
                         "public, max-age=31536000, immutable" if immutable else "no-cache")
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(body)
        return True

    # ---------- 会话 ----------
    def _token(self):
        raw = self.headers.get("Cookie", "")
        if not raw:
            return None
        ck = SimpleCookie()
        try:
            ck.load(raw)
        except Exception:
            return None
        if SESSION_COOKIE in ck:
            return ck[SESSION_COOKIE].value
        return None

    def _logged_in(self):
        t = self._token()
        return t if (t and t in STATE["sessions"]) else None

    def _read_json(self):
        ln = int(self.headers.get("Content-Length") or 0)
        raw = self.rfile.read(ln) if ln else b""
        if not raw:
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    @staticmethod
    def _set_cookie(token, clear=False):
        if clear:
            return (f"{SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax")
        return (f"{SESSION_COOKIE}={token}; Path=/; Max-Age=86400; "
                f"HttpOnly; SameSite=Lax")

    # ---------- API ----------
    def handle_api(self, method, path):
        p = [x for x in path.split("/") if x != ""]
        # p 形如 ['api','rooms','0','join']
        sid = self._logged_in()

        # ===== 公开端点 (与线上一致, 无需登录) =====
        if method == "GET" and path == "/api/rooms":
            with LOCK:
                return self.send_json(200, STATE["rooms_doc"])
        if method == "GET" and path == "/api/room-types":
            return self._fixture("room-types.json")
        if method == "GET" and path == "/api/auth/captcha":
            return self._fixture("captcha.json")
        if method == "GET" and path == "/api/auth/session":
            if sid:
                return self.send_json(200, {"authenticated": True, "user": public_user(),
                                            "csrfToken": CSRF_TOKEN})
            return self._fixture("session.json")
        if method == "GET" and path.startswith("/api/auth/verify-email"):
            return self.send_api_error("INVALID_TOKEN", "验证链接无效或已过期", 400)

        # ===== 媒体文件 =====
        if method in ("GET", "HEAD") and path.startswith("/api/media/"):
            return self._media(path)

        # ----- 认证 (无需既有会话) -----
        if method == "POST" and path == "/api/auth/login":
            token = f"sess-{int(time.time()*1000)}"
            with LOCK:
                STATE["sessions"].add(token)
            return self.send_json(200, {"ok": True, "csrfToken": CSRF_TOKEN,
                                        "user": public_user()},
                                  {"Set-Cookie": self._set_cookie(token)})
        if method == "POST" and path == "/api/auth/logout":
            with LOCK:
                if sid:
                    STATE["sessions"].discard(sid)
            return self.send_bytes(200, b"{}", "application/json; charset=utf-8",
                                   {"Set-Cookie": self._set_cookie("", clear=True)})
        if method == "POST" and path in ("/api/auth/register/code", "/api/auth/register"):
            return self.send_api_error("EMAIL_UNAVAILABLE",
                                       "镜像环境未配置邮件服务，注册接口不可用；可直接任意账号登录体验", 503)

        # ===== 以下均需登录 =====
        if not sid:
            # 已知登录态资源: 与线上一致返回 401 AUTH_REQUIRED
            if path == "/api/me" or path.startswith("/api/me/") or path.startswith("/api/rooms/"):
                return self.send_api_error("AUTH_REQUIRED", "请先登录", 401)
            if method in ("POST", "PUT", "PATCH", "DELETE"):
                return self.send_api_error("AUTH_REQUIRED", "请先登录", 401)
            return self.send_api_error("NOT_FOUND", "Not found", 404)

        # ----- 个人 -----
        if path == "/api/me" and method in ("GET", "PATCH"):
            user = public_user()
            if method == "PATCH":
                user.update({k: v for k, v in self._read_json().items()
                             if k in ("username", "name", "avatarUrl")})
                GUEST.update(user)
            return self.send_json(200, {"user": user})
        if method == "POST" and path == "/api/me/avatar":
            ln = int(self.headers.get("Content-Length") or 0)
            if ln:
                self.rfile.read(ln)
            return self.send_json(200, {"ok": True, "avatarUrl": None})
        if method == "POST" and path == "/api/me/password":
            return self.send_json(200, {"ok": True})

        # ----- 房间集合 -----
        if path == "/api/rooms" and method == "POST":
            return self._create_room()

        # ----- /api/rooms/:id/... -----
        if len(p) >= 3 and p[0] == "api" and p[1] == "rooms":
            return self._room_subresource(method, p, sid)

        # 管理端 (镜像用户非管理员)
        if path.startswith("/api/admin/"):
            return self.send_api_error("NOT_FOUND", "Not found", 404)

        return self.send_api_error("NOT_FOUND", "Not found", 404)

    # ----- 静态快照 (公开) -----
    def _fixture(self, name):
        fp = os.path.join(FIXTURES, name)
        if not os.path.exists(fp):
            return self.send_api_error("NOT_FOUND", "Not found", 404)
        with open(fp, "rb") as f:
            self.send_bytes(200, f.read(), "application/json; charset=utf-8")

    def _media(self, path):
        fp = os.path.join(ROOT, unquote(path.lstrip("/")).replace("/", os.sep))
        if os.path.abspath(fp).startswith(os.path.abspath(ROOT)) and os.path.isfile(fp):
            return bool(self.send_file(fp))
        self.send_api_error("NOT_FOUND", "Not found", 404)

    # ----- 房间操作 -----
    def _create_room(self):
        body = self._read_json()
        with LOCK:
            rid = str(STATE["next_rid"])
            STATE["next_rid"] += 1
            rtype = next((t for t in load_json("room-types.json", {"roomTypes": []})
                          .get("roomTypes", []) if str(t.get("id")) == str(body.get("roomTypeId", 1))),
                         {"name": "聊天", "bitrateKbps": 128})
            room = {
                "id": rid, "roomNo": rid, "roomNumber": rid,
                "name": str(body.get("name") or "新建房间"),
                "topic": "", "category": rtype.get("name", "聊天"),
                "roomTypeId": body.get("roomTypeId", 1),
                "ownerName": GUEST["username"], "ownerAvatar": None,
                "ownerId": GUEST["id"], "ownerAccount": GUEST["account"],
                "capacity": body.get("capacity"), "onlineCount": 1,
                "speakerCount": 0,
                "bitrateKbps": body.get("bitrateKbps", rtype.get("bitrateKbps", 128)),
                "bitrate": body.get("bitrateKbps", rtype.get("bitrateKbps", 128)),
                "stereo": True, "chatEnabled": True,
                "voiceAvailable": False, "voiceConfigured": True,
                "role": "owner", "currentUser": "owner",
            }
            STATE["rooms"][rid] = {"room": room,
                                   "members": [dict(GUEST, role="owner")],
                                   "speakers": []}
            STATE["chats"][rid] = []
            STATE["rooms_doc"]["rooms"].append(room)
            self.send_json(200, {"room": room})

    def _room_view(self, rid):
        data = STATE["rooms"].get(rid)
        if not data:
            return None
        view = copy.deepcopy(data)
        view["room"]["onlineCount"] = len(view["members"])
        view["room"]["speakerCount"] = len(view["speakers"])
        return view

    def _room_subresource(self, method, p, sid):
        rid = unquote(p[2])
        sub = p[3:]
        room = STATE["rooms"].get(rid)
        if room is None:
            return self.send_api_error("NOT_FOUND", "Not found", 404)

        joined = any(str(m.get("id")) == str(GUEST["id"]) for m in room["members"])

        # POST /join
        if sub == ["join"] and method == "POST":
            with LOCK:
                if not joined:
                    room["members"].append(dict(GUEST, role="member"))
                STATE["join_since"][(sid, rid)] = time.time()
                room["room"]["role"] = "member" if room["room"].get("ownerId") != GUEST["id"] else "owner"
            # 与线上 voiceAvailable:false 房间一致: 无 token -> 前端进入房间页并降级
            return self.send_json(200, {"canPublish": False, "token": None,
                                        "serverUrl": None,
                                        "voiceMessage": "镜像环境未部署 LiveKit 语音节点"})

        if not joined and method != "GET":
            return self.send_api_error("ROOM_NOT_JOINED", "请先进入房间", 403)

        # GET /api/rooms/:id
        if not sub and method == "GET":
            with LOCK:
                view = self._room_view(rid)
            return self.send_json(200, view)

        # 公屏
        if sub == ["chat"]:
            if method == "GET":
                with LOCK:
                    return self.send_json(200, {"enabled": room["room"].get("chatEnabled", True),
                                                "messages": list(STATE["chats"][rid])})
            if method == "POST":
                body = self._read_json()
                content = str(body.get("content") or body.get("message") or "").strip()
                if not content:
                    return self.send_api_error("EMPTY_MESSAGE", "消息不能为空", 400)
                msg = {"user": {"name": GUEST["username"], "avatarUrl": None,
                                "id": GUEST["id"]},
                       "name": GUEST["username"],
                       "content": content[:300],
                       "createdAt": time.strftime("%H:%M")}
                with LOCK:
                    STATE["chats"][rid].append(msg)
                return self.send_json(200, {"ok": True, "message": msg})
        if sub == ["chat", "clear"] and method == "POST":
            if room["room"].get("ownerId") != GUEST["id"]:
                return self.send_api_error("FORBIDDEN", "无权操作", 403)
            with LOCK:
                STATE["chats"][rid] = []
            return self.send_json(200, {"ok": True})
        if sub == ["chat", "setting"] and method in ("POST", "PATCH"):
            if room["room"].get("ownerId") != GUEST["id"]:
                return self.send_api_error("FORBIDDEN", "无权操作", 403)
            body = self._read_json()
            with LOCK:
                room["room"]["chatEnabled"] = not bool(body.get("disabled", False))
            return self.send_json(200, {"enabled": room["room"]["chatEnabled"]})

        # 心跳
        if sub == ["heartbeat"] and method == "POST":
            since = STATE["join_since"].get((sid, rid), time.time())
            secs = int(time.time() - since)
            GUEST["roomSeconds"] = secs
            return self.send_json(200, {"roomSeconds": secs,
                                        "level": 1 + secs // 3600})

        # 语音凭证: 镜像无 LiveKit, 一律降级无凭证
        if sub == ["voice-token"] and method == "POST":
            return self.send_json(200, {"canPublish": False, "token": None,
                                        "serverUrl": None})

        # 麦位
        if sub == ["speakers"] and method == "POST":
            body = self._read_json()
            seat = body.get("seatIndex")
            seat = int(seat) if seat is not None else self._free_seat(room)
            with LOCK:
                room["speakers"] = [s for s in room["speakers"]
                                    if str(s.get("id")) != str(GUEST["id"])]
                sp = dict(GUEST, role=room["room"].get("role", "member"),
                          seatIndex=seat, isSpeaking=False, speaking=False,
                          audioLevel=0, identity=f"u-{GUEST['id']}")
                room["speakers"].append(sp)
                room["speakers"].sort(key=lambda s: s["seatIndex"])
            return self.send_json(200, {"ok": True, "speaker": sp})
        if sub == ["speakers", "me"] and method == "DELETE":
            with LOCK:
                room["speakers"] = [s for s in room["speakers"]
                                    if str(s.get("id")) != str(GUEST["id"])]
            return self.send_json(200, {"ok": True})
        if sub == ["speakers", "me", "activity"] and method == "PATCH":
            body = self._read_json()
            with LOCK:
                for s in room["speakers"]:
                    if str(s.get("id")) == str(GUEST["id"]):
                        s["isSpeaking"] = bool(body.get("speaking"))
                        s["speaking"] = bool(body.get("speaking"))
            return self.send_json(200, {"ok": True})

        # 管理员/踢人 (访客无权)
        if sub[-1:] == ["admins"] or sub[-1:] == ["kick"]:
            return self.send_api_error("FORBIDDEN", "无权操作", 403)

        # 离房
        if sub == ["leave"] and method == "POST":
            with LOCK:
                room["members"] = [m for m in room["members"]
                                   if str(m.get("id")) != str(GUEST["id"])]
                room["speakers"] = [s for s in room["speakers"]
                                    if str(s.get("id")) != str(GUEST["id"])]
                STATE["join_since"].pop((sid, rid), None)
            return self.send_json(200, {"ok": True})

        return self.send_api_error("NOT_FOUND", "Not found", 404)

    @staticmethod
    def _free_seat(room):
        used = {int(s["seatIndex"]) for s in room["speakers"]}
        i = 1
        while i in used:
            i += 1
        return i

    # ---------- 路由 ----------
    def _route(self, method):
        path = urlparse(self.path).path
        if ".." in path:
            return self.send_bytes(400, b"Bad Request", "text/plain")
        if path.startswith("/api/"):
            return self.handle_api(method, path)
        rel = "index.html" if path in ("/", "") else unquote(path.lstrip("/"))
        fp = os.path.join(ROOT, rel.replace("/", os.sep))
        if os.path.abspath(fp).startswith(os.path.abspath(ROOT)) and os.path.isfile(fp):
            return bool(self.send_file(fp, immutable=rel.startswith("assets/")))
        # 与线上一致: 未知非 API 路径为 nginx 404
        self.send_bytes(404, NGINX_404, "text/html")

    def do_GET(self): self._route("GET")
    def do_HEAD(self): self._route("HEAD")
    def do_POST(self): self._route("POST")
    def do_PUT(self): self._route("PUT")
    def do_PATCH(self): self._route("PATCH")
    def do_DELETE(self): self._route("DELETE")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Credentials", "true")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "content-type,x-csrf-token")
        self.end_headers()


def main():
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8088
    srv = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"声趣语音镜像回放: http://127.0.0.1:{port}/")
    print(f"镜像目录: {ROOT}")
    print("房间页体验: 登录(任意账号密码) -> 点击「声趣管理房间」进入")
    print("Ctrl+C 停止")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        srv.shutdown()


if __name__ == "__main__":
    main()
